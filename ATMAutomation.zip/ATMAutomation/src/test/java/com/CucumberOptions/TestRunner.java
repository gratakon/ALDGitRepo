package com.CucumberOptions;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;



//@RunWith(Cucumber.class)
@CucumberOptions(
		
		plugin = {"pretty", 
				//"html:target/cucumberHTMLResults",
				//"json:target/cucumberJsonResults/cucumberALD.json",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
                },
		features="Scenarios/Week4.feature",
		//features="Scenarios",
		glue= {"com.ALD.StepDefs"},
		//tags={"@testingtest"},
		dryRun=false,
		strict=false,
		monochrome=true
		)

public class TestRunner extends AbstractTestNGCucumberTests{
	
	
	
	
	
		
		
	}
	
	


